=== Open Social Share ===
Contributors: MojoAuth
Donate link: https://mojoauth.com/
Tags: WordPress plugin, BuddyPress, bbpress, multisite, Social9, Authentication, social plugins
Requires at least: 3.4
Tested up to: 5.7.2
Stable tag: 1.0
Requires PHP: 5.6
License: GPLv2 or later

MojoAuth provides a secure and delightful experience to your customer with passwordless. Here, you'll find comprehensive guides and documentation to help you to start working with MojoAuth APIs.

== Description ==

Description Here

== Installation ==

= Step-by-step installation documents =
After downloading the plugin, you will find MojoAuth located under Plugins.
Activate your plugin in WordPress by clicking on "MojoAuth".

== Screenshots ==
1. **Social Sharing Admin UI**: This is an example presentation social sharing. There are multiple themes available.


== Changelog ==

= 1.0 =
* Initial release

== Upgrade Notice ==

= 1.0 =
* Initial release
